#include "Graphe.h"


using namespace std;

int main()
{
    Graphe g{"data_arcs.txt"};
    menu();
    cout << "Bonjour  c'est Margaux" << endl;
    return 0;
}
